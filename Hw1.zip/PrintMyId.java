public class PrintMyId{
  public static void main(String[] args){
//My Name:Cianni Hayes//
//My Student ID: cih219//
//Homework #: 1//
//PrintMyId.java : prints my Lehigh login id which is seven lines tall and made up of @'s.//
//Input: None//
//Output: My student Id number//
    
System.out.println("@@@@@@@@@@@@ @@@@@@@@@@@@@  @          @  @@@@@@@@@@@@   @  @@@@@@@@@@@@@");
System.out.println("@                   @       @          @             @   @  @           @");
System.out.println("@                   @       @          @             @   @  @           @");
System.out.println("@                   @       @@@@@@@@@@@@  @@@@@@@@@@@@   @  @@@@@@@@@@@@@");        
System.out.println("@                   @       @          @  @              @              @");
System.out.println("@                   @       @          @  @              @              @");
System.out.println("@@@@@@@@@@@@  @@@@@@@@@@@@@ @          @  @@@@@@@@@@@@   @  @@@@@@@@@@@@@");

  }
}